import React, { useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput } from "react-native";
import { supabase } from "../src/lib/supabase";
import { useSession } from "../src/store/session";

export default function Verification() {
  const {user}=useSession(); const [legalName,setLegalName]=useState(""); const [country,setCountry]=useState(""); const [reason,setReason]=useState(""); const [busy,setBusy]=useState(false);
  async function submit(){
    if(!user)return;
    if(!legalName.trim()||!country.trim())return Alert.alert("More information","Enter your legal name and country.");
    setBusy(true);
    try{
      const {data:existing,error:read}=await supabase.from("zentro_verification_requests").select("id,status").eq("user_id",user.id).eq("status","pending").limit(1).maybeSingle();
      if(read)throw read; if(existing)return Alert.alert("Already submitted","Your request is already awaiting review.");
      const {error}=await supabase.from("zentro_verification_requests").insert({user_id:user.id,status:"pending",submitted_at:new Date().toISOString(),reviewed_at:null,reviewed_by:null,legal_name:legalName.trim(),country:country.trim(),reason:reason.trim()});
      if(error)throw error; Alert.alert("Submitted","Your application is queued for human review.");
    }catch(e:any){Alert.alert("Could not submit",e.message||"Your database may need the verification fields migration.")}finally{setBusy(false)}
  }
  return <ScrollView contentContainerStyle={styles.page}><Text style={styles.title}>Request Verification</Text><Text style={styles.note}>Verification is reviewed by authorized Zentro staff. A badge is only created after approval.</Text>
    <TextInput placeholder="Full legal name" value={legalName} onChangeText={setLegalName} style={styles.input}/>
    <TextInput placeholder="Country" value={country} onChangeText={setCountry} style={styles.input}/>
    <TextInput placeholder="Why should this account be verified?" value={reason} onChangeText={setReason} multiline style={[styles.input,{height:120,textAlignVertical:"top"}]}/>
    <Pressable onPress={submit} disabled={busy} style={styles.btn}><Text style={{color:"#fff",fontWeight:"900"}}>{busy?"Submitting…":"Submit for review"}</Text></Pressable>
  </ScrollView>
}
const styles=StyleSheet.create({page:{padding:18,gap:14},title:{fontSize:27,fontWeight:"900"},note:{color:"#666",lineHeight:20},input:{borderWidth:1,borderColor:"#ddd",borderRadius:14,padding:14},btn:{backgroundColor:"#111827",padding:16,borderRadius:14,alignItems:"center"}});
