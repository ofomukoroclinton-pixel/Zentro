import React, { useCallback, useEffect, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { getConversations, displayName, timeAgo } from "../../src/lib/zentro";
import { useSession } from "../../src/store/session";
import { router } from "expo-router";

export default function Messages() {
  const { user }=useSession();
  const [items,setItems]=useState<any[]>([]);
  const load=useCallback(async()=>{if(user)setItems(await getConversations(user.id))},[user]);
  useEffect(()=>{load().catch(console.error)},[load]);
  return <View style={styles.page}><Text style={styles.title}>Messages</Text>
    <FlatList data={items} keyExtractor={x=>x.id} onRefresh={load} refreshing={false}
      ListEmptyComponent={<Text style={styles.empty}>Your conversations will appear here.</Text>}
      renderItem={({item})=><Pressable style={styles.row} onPress={()=>router.push({pathname:"/chat/[id]",params:{id:item.id,name:displayName(item.profile)}})}>
        {item.profile?.avatar_url?<Image source={item.profile.avatar_url} style={styles.avatar}/>:<View style={styles.avatar}/>}
        <View style={{flex:1}}><Text style={styles.name}>{displayName(item.profile)}</Text><Text numberOfLines={1} style={styles.preview}>{item.latest?.content||"Start a conversation"}</Text></View>
        <Text style={styles.time}>{item.latest?.created_at?timeAgo(item.latest.created_at):""}</Text>
      </Pressable>}/>
  </View>
}
const styles=StyleSheet.create({page:{flex:1,padding:16},title:{fontSize:27,fontWeight:"900",marginBottom:12},row:{flexDirection:"row",alignItems:"center",gap:12,paddingVertical:12,borderBottomWidth:1,borderBottomColor:"#eee"},avatar:{width:48,height:48,borderRadius:24,backgroundColor:"#e7e7ee"},name:{fontWeight:"800"},preview:{color:"#777",marginTop:3},time:{color:"#888",fontSize:12},empty:{color:"#777",paddingTop:30}});
