-- Zentro notification + verification hardening.
-- Run this in Supabase SQL editor after reviewing existing table definitions.

create extension if not exists pgcrypto;

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null default 'activity',
  title text,
  message text,
  data jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.notifications
  add column if not exists type text,
  add column if not exists title text,
  add column if not exists message text,
  add column if not exists data jsonb default '{}'::jsonb,
  add column if not exists read_at timestamptz,
  add column if not exists created_at timestamptz default now();

create index if not exists notifications_user_created_idx
  on public.notifications(user_id, created_at desc);

create table if not exists public.push_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  expo_push_token text not null unique,
  platform text,
  updated_at timestamptz not null default now()
);

create index if not exists push_tokens_user_idx on public.push_tokens(user_id);

create table if not exists public.notification_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  push_enabled boolean not null default true,
  email_enabled boolean not null default true,
  updated_at timestamptz not null default now()
);

alter table public.notifications enable row level security;
alter table public.push_tokens enable row level security;
alter table public.notification_preferences enable row level security;

-- Users can read and mark their own notifications.
drop policy if exists "notifications_select_own" on public.notifications;
create policy "notifications_select_own" on public.notifications
for select using (auth.uid() = user_id);

drop policy if exists "notifications_update_own" on public.notifications;
create policy "notifications_update_own" on public.notifications
for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Clients may register/update only their own device token.
drop policy if exists "push_tokens_select_own" on public.push_tokens;
create policy "push_tokens_select_own" on public.push_tokens
for select using (auth.uid() = user_id);

drop policy if exists "push_tokens_insert_own" on public.push_tokens;
create policy "push_tokens_insert_own" on public.push_tokens
for insert with check (auth.uid() = user_id);

drop policy if exists "push_tokens_update_own" on public.push_tokens;
create policy "push_tokens_update_own" on public.push_tokens
for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "push_tokens_delete_own" on public.push_tokens;
create policy "push_tokens_delete_own" on public.push_tokens
for delete using (auth.uid() = user_id);

drop policy if exists "notification_preferences_own" on public.notification_preferences;
create policy "notification_preferences_own" on public.notification_preferences
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- IMPORTANT: no client INSERT policy exists for notifications.
-- Notifications should be created by trusted server-side operations only.
-- This prevents a normal user from creating notifications for another user.

-- Verification audit trail.
create table if not exists public.verification_audit_log (
  id uuid primary key default gen_random_uuid(),
  request_id uuid,
  applicant_user_id uuid not null references auth.users(id) on delete cascade,
  actor_user_id uuid not null references auth.users(id) on delete restrict,
  action text not null check (action in ('approved','rejected','more_info','revoked')),
  note text,
  created_at timestamptz not null default now()
);

alter table public.verification_audit_log enable row level security;
-- Read/write policies should be granted only to your server-side founder/admin role.
-- Do not grant ordinary authenticated users access to this table.

-- Realtime is required for the in-app notification center.
alter publication supabase_realtime add table public.notifications;
