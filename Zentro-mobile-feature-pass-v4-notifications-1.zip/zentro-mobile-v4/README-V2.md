# Zentro mobile migration — feature pass v2

This build goes beyond the first migration foundation.

Implemented against the actual PWA/Supabase table names found in the supplied project:
- Home feed reads `posts` + `profiles` and preserves per-card optimistic like state.
- Video is a distinct feed filtered by `media_type = video`, with native Expo video playback.
- Comments write to `comments`.
- Messages read/write `direct_messages` with a real conversation route and optimistic outgoing messages.
- Create Post uploads image/video to the existing `post-images` bucket and inserts into `posts`.
- Verification submits to `zentro_verification_requests`; approved badges are represented by `zentro_verified_members`.
- Founder verification queue mirrors the existing PWA approval flow and relies on Supabase authorization.
- Verification request fields are supplied as an additive SQL migration.
- The app uses Expo Router, so `zentro://...` and future universal/app links can route into real screens.

Important production notes:
1. The verification form is intentionally simple in this pass. Government-ID upload, liveness, document OCR, duplicate detection, and manual evidence review should be added behind a secure server/Edge Function rather than trusting client input.
2. Audio/video calls are NOT falsely represented as complete here. Proper calls require WebRTC signaling, TURN, permissions, and lifecycle handling.
3. Existing PWA behavior remains the reference for additional community/romance/notifications/profile features; those should be migrated screen-by-screen rather than replacing all feeds with one generic layout.
4. Supabase RLS must enforce founder/admin permissions. Client-side role checks are never sufficient.
