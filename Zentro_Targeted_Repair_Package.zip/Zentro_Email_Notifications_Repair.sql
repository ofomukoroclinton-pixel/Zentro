-- ZENTRO LIKE + MESSAGE DELETE + EMAIL ACTIVITY NOTIFICATIONS REPAIR
-- Additive/safe: does not delete accounts, posts, likes, comments, messages, or notification rows.
-- Run once in the Supabase SQL Editor for the SAME Zentro project.

begin;

-- 1) Repair likes: authenticated members may read counts, like as themselves, and unlike only themselves.
alter table public.post_likes enable row level security;
drop policy if exists zentro_likes_read_authenticated on public.post_likes;
create policy zentro_likes_read_authenticated on public.post_likes
  for select to authenticated using (true);
drop policy if exists zentro_likes_insert_own on public.post_likes;
create policy zentro_likes_insert_own on public.post_likes
  for insert to authenticated with check (user_id = auth.uid());
drop policy if exists zentro_likes_delete_own on public.post_likes;
create policy zentro_likes_delete_own on public.post_likes
  for delete to authenticated using (user_id = auth.uid());
grant select, insert, delete on public.post_likes to authenticated;

-- 2) Ensure sent-message deletion is allowed only for the sender.
alter table public.direct_messages enable row level security;
drop policy if exists zentro_sender_delete_own_messages on public.direct_messages;
create policy zentro_sender_delete_own_messages on public.direct_messages
  for delete to authenticated using (sender_id = auth.uid());
grant delete on public.direct_messages to authenticated;

-- 3) The old unique constraint could make a repeat like/message fail because its notification
-- insert collided with an earlier notification. Keep each activity as a separate notification
-- row so the email webhook sends an email for every new event.
alter table public.zentro_notifications drop constraint if exists zentro_notification_unique;
create index if not exists zentro_notifications_recipient_created_idx
  on public.zentro_notifications(recipient_id, created_at desc);
alter table public.zentro_notifications enable row level security;
drop policy if exists zentro_email_notifications_read_own on public.zentro_notifications;
create policy zentro_email_notifications_read_own on public.zentro_notifications
  for select to authenticated using (recipient_id = auth.uid());
drop policy if exists zentro_email_notifications_update_own on public.zentro_notifications;
create policy zentro_email_notifications_update_own on public.zentro_notifications
  for update to authenticated using (recipient_id = auth.uid()) with check (recipient_id = auth.uid());
grant select, update on public.zentro_notifications to authenticated;

-- Keep any legacy helper safe now that the old unique constraint is removed.
create or replace function public.zentro_create_activity_notification(
  p_recipient uuid, p_actor uuid, p_type text, p_message text
) returns void language plpgsql security definer set search_path=public as $$
declare actor_name text := 'Someone';
begin
  if p_recipient is null or p_actor is null or p_recipient = p_actor then return; end if;
  select coalesce(nullif(btrim(display_name),''),nullif(btrim(username),''),'Someone')
    into actor_name from public.profiles where id=p_actor;
  insert into public.zentro_notifications(recipient_id,actor_id,type,message,related_user_id)
  values(p_recipient,p_actor,coalesce(nullif(p_type,''),'activity'),
    coalesce(nullif(btrim(p_message),''),actor_name||' interacted with you on Zentro.'),p_actor);
end; $$;

-- Likes: notify the owner of the post; never notify the actor about their own action.
create or replace function public.zentro_engagement_notify_like()
returns trigger language plpgsql security definer set search_path=public as $$
declare owner_id uuid; actor_name text;
begin
  select user_id into owner_id from public.posts where id=new.post_id;
  if owner_id is not null and owner_id<>new.user_id then
    select coalesce(nullif(btrim(display_name),''),nullif(btrim(username),''),'A Zentro member') into actor_name from public.profiles where id=new.user_id;
    insert into public.zentro_notifications(recipient_id,actor_id,type,message,related_user_id)
    values(owner_id,new.user_id,'like',coalesce(actor_name,'A Zentro member')||' liked your post on Zentro.',new.user_id);
  end if;
  return new;
end; $$;
drop trigger if exists zentro_engagement_notify_like_trigger on public.post_likes;
create trigger zentro_engagement_notify_like_trigger after insert on public.post_likes
for each row execute function public.zentro_engagement_notify_like();

-- Comments.
create or replace function public.zentro_engagement_notify_comment()
returns trigger language plpgsql security definer set search_path=public as $$
declare owner_id uuid; actor_name text;
begin
  select user_id into owner_id from public.posts where id=new.post_id;
  if owner_id is not null and owner_id<>new.user_id then
    select coalesce(nullif(btrim(display_name),''),nullif(btrim(username),''),'A Zentro member') into actor_name from public.profiles where id=new.user_id;
    insert into public.zentro_notifications(recipient_id,actor_id,type,message,related_user_id)
    values(owner_id,new.user_id,'comment',coalesce(actor_name,'A Zentro member')||' commented on your Zentro post.',new.user_id);
  end if;
  return new;
end; $$;
drop trigger if exists zentro_engagement_notify_comment_trigger on public.comments;
create trigger zentro_engagement_notify_comment_trigger after insert on public.comments
for each row execute function public.zentro_engagement_notify_comment();

-- Follows.
create or replace function public.zentro_engagement_notify_follow()
returns trigger language plpgsql security definer set search_path=public as $$
declare actor_name text;
begin
  if new.following_id is not null and new.follower_id is not null and new.following_id<>new.follower_id then
    select coalesce(nullif(btrim(display_name),''),nullif(btrim(username),''),'A Zentro member') into actor_name from public.profiles where id=new.follower_id;
    insert into public.zentro_notifications(recipient_id,actor_id,type,message,related_user_id)
    values(new.following_id,new.follower_id,'follow',coalesce(actor_name,'A Zentro member')||' started following you on Zentro.',new.follower_id);
  end if;
  return new;
end; $$;
drop trigger if exists zentro_engagement_notify_follow_trigger on public.follows;
create trigger zentro_engagement_notify_follow_trigger after insert on public.follows
for each row execute function public.zentro_engagement_notify_follow();

-- Private messages.
create or replace function public.zentro_engagement_notify_message()
returns trigger language plpgsql security definer set search_path=public as $$
declare actor_name text;
begin
  if new.receiver_id is not null and new.sender_id is not null and new.receiver_id<>new.sender_id then
    select coalesce(nullif(btrim(display_name),''),nullif(btrim(username),''),'A Zentro member') into actor_name from public.profiles where id=new.sender_id;
    insert into public.zentro_notifications(recipient_id,actor_id,type,message,related_user_id)
    values(new.receiver_id,new.sender_id,'message','New private message from '||coalesce(actor_name,'a Zentro member')||' on Zentro.',new.sender_id);
  end if;
  return new;
end; $$;
drop trigger if exists zentro_engagement_notify_message_trigger on public.direct_messages;
create trigger zentro_engagement_notify_message_trigger after insert on public.direct_messages
for each row execute function public.zentro_engagement_notify_message();

-- New posts from people the recipient follows.
create or replace function public.zentro_engagement_notify_new_post()
returns trigger language plpgsql security definer set search_path=public as $$
declare actor_name text;
begin
  select coalesce(nullif(btrim(display_name),''),nullif(btrim(username),''),'A Zentro member') into actor_name from public.profiles where id=new.user_id;
  insert into public.zentro_notifications(recipient_id,actor_id,type,message,related_user_id)
  select f.follower_id,new.user_id,'post',coalesce(actor_name,'A Zentro member')||' shared a new post on Zentro.',new.user_id
  from public.follows f where f.following_id=new.user_id and f.follower_id<>new.user_id;
  return new;
end; $$;
drop trigger if exists zentro_engagement_notify_new_post_trigger on public.posts;
create trigger zentro_engagement_notify_new_post_trigger after insert on public.posts
for each row execute function public.zentro_engagement_notify_new_post();

-- Match emails to both members, if the current match table has the expected columns.
create or replace function public.zentro_engagement_notify_match()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.user_a is not null and new.user_b is not null and new.user_a<>new.user_b then
    insert into public.zentro_notifications(recipient_id,actor_id,type,message,related_user_id)
    values (new.user_a,new.user_b,'match','You have a new Zentro match!',new.user_b),
           (new.user_b,new.user_a,'match','You have a new Zentro match!',new.user_a);
  end if;
  return new;
end; $$;
do $$ begin
  if to_regclass('public.zentro_matches') is not null
     and exists(select 1 from information_schema.columns where table_schema='public' and table_name='zentro_matches' and column_name='user_a')
     and exists(select 1 from information_schema.columns where table_schema='public' and table_name='zentro_matches' and column_name='user_b') then
    execute 'drop trigger if exists zentro_engagement_notify_match_trigger on public.zentro_matches';
    execute 'create trigger zentro_engagement_notify_match_trigger after insert on public.zentro_matches for each row execute function public.zentro_engagement_notify_match()';
  end if;
end $$;

-- Community chat: notify all other members if the installed schema uses sender_id/community_id
-- and community_members(user_id, community_id). The check avoids errors on older schemas.
create or replace function public.zentro_engagement_notify_community_message()
returns trigger language plpgsql security definer set search_path=public as $$
declare sender uuid; community uuid; actor_name text;
begin
  sender := nullif(to_jsonb(new)->>'sender_id','')::uuid;
  community := nullif(to_jsonb(new)->>'community_id','')::uuid;
  if sender is null or community is null then return new; end if;
  select coalesce(nullif(btrim(display_name),''),nullif(btrim(username),''),'A Zentro member') into actor_name from public.profiles where id=sender;
  execute 'insert into public.zentro_notifications(recipient_id,actor_id,type,message,related_user_id) select cm.user_id,$1,''community_message'',$2,$1 from public.community_members cm where cm.community_id=$3 and cm.user_id<>$1'
    using sender,coalesce(actor_name,'A Zentro member')||' sent a message in your Zentro community.',community;
  return new;
end; $$;
do $$ begin
  if to_regclass('public.community_message') is not null
     and exists(select 1 from information_schema.columns where table_schema='public' and table_name='community_message' and column_name='sender_id')
     and exists(select 1 from information_schema.columns where table_schema='public' and table_name='community_message' and column_name='community_id')
     and to_regclass('public.community_members') is not null
     and exists(select 1 from information_schema.columns where table_schema='public' and table_name='community_members' and column_name='user_id')
     and exists(select 1 from information_schema.columns where table_schema='public' and table_name='community_members' and column_name='community_id') then
    execute 'drop trigger if exists zentro_engagement_notify_community_message_trigger on public.community_message';
    execute 'create trigger zentro_engagement_notify_community_message_trigger after insert on public.community_message for each row execute function public.zentro_engagement_notify_community_message()';
  end if;
end $$;

-- Make in-app notifications update live when a user is viewing the notification screen.
do $$ begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
     and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='zentro_notifications') then
    execute 'alter publication supabase_realtime add table public.zentro_notifications';
  end if;
end $$;

commit;

-- EMAIL DELIVERY SETUP IS ALSO REQUIRED (instructions in README):
-- deploy supabase/functions/zentro-notification-email/index.ts, set RESEND_API_KEY,
-- RESEND_FROM_EMAIL, ZENTRO_APP_URL and ZENTRO_WEBHOOK_SECRET, then create an INSERT
-- Database Webhook for public.zentro_notifications with x-zentro-webhook-secret header.
