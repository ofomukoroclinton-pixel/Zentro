import { Stack } from "expo-router";
import { SessionProvider } from "../src/store/session";

export default function RootLayout() {
  return <SessionProvider>
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="auth" />
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="chat/[id]" />
      <Stack.Screen name="call/[id]" />
      <Stack.Screen name="create-post" />
      <Stack.Screen name="notifications" />
      <Stack.Screen name="settings/notifications" />
      <Stack.Screen name="verification" />
      <Stack.Screen name="founder/verification" />
      <Stack.Screen name="founder/announcement" />
    </Stack>
  </SessionProvider>;
}
