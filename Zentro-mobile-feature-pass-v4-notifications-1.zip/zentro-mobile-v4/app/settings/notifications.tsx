import React, { useEffect, useState } from "react";
import { Alert, Pressable, StyleSheet, Switch, Text, View } from "react-native";
import { supabase } from "../../src/lib/supabase";
import { useSession } from "../../src/store/session";

export default function NotificationSettings() {
  const { user } = useSession();
  const [push, setPush] = useState(true);
  const [email, setEmail] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("notification_preferences").select("*").eq("user_id", user.id).maybeSingle()
      .then(({ data }) => {
        if (data) { setPush(data.push_enabled !== false); setEmail(data.email_enabled !== false); }
      });
  }, [user?.id]);

  async function save(nextPush: boolean, nextEmail: boolean) {
    if (!user) return;
    setBusy(true);
    setPush(nextPush); setEmail(nextEmail);
    try {
      const { error } = await supabase.from("notification_preferences").upsert({
        user_id: user.id,
        push_enabled: nextPush,
        email_enabled: nextEmail,
        updated_at: new Date().toISOString()
      });
      if (error) throw error;
    } catch (e: any) {
      Alert.alert("Could not save", e.message || "Please try again.");
    } finally { setBusy(false); }
  }

  return <View style={styles.page}>
    <Text style={styles.title}>Notification Settings</Text>
    <View style={styles.row}><View style={{flex:1}}><Text style={styles.label}>Push notifications</Text><Text style={styles.note}>Show Zentro alerts in the phone notification panel.</Text></View><Switch disabled={busy} value={push} onValueChange={v=>save(v,email)} /></View>
    <View style={styles.row}><View style={{flex:1}}><Text style={styles.label}>Email notifications</Text><Text style={styles.note}>Send activity alerts to the email used for this Zentro account.</Text></View><Switch disabled={busy} value={email} onValueChange={v=>save(push,v)} /></View>
    <Pressable onPress={()=>Alert.alert("How it works","Zentro sends transactional activity email to your account email. Push notifications are delivered to registered devices.")} style={styles.help}><Text>About Zentro notifications</Text></Pressable>
  </View>;
}
const styles=StyleSheet.create({page:{padding:18,gap:8},title:{fontSize:28,fontWeight:"900",marginBottom:12},row:{flexDirection:"row",alignItems:"center",paddingVertical:18,borderBottomWidth:1,borderBottomColor:"#eee"},label:{fontWeight:"900",fontSize:16},note:{color:"#777",lineHeight:19,marginTop:3,paddingRight:10},help:{padding:16,marginTop:14,borderRadius:14,borderWidth:1,borderColor:"#ddd",alignItems:"center"}});
