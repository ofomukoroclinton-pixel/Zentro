-- Additive migration for Zentro mobile verification.
-- Existing PWA rows remain valid because all new fields are nullable.
alter table if exists public.zentro_verification_requests
  add column if not exists legal_name text,
  add column if not exists country text,
  add column if not exists reason text;

-- IMPORTANT:
-- Keep approval authoritative on the server with RLS policies.
-- Only founder/admin identities should be allowed to:
--   1) update verification request status/reviewer fields
--   2) insert/update/delete zentro_verified_members
-- Normal clients must never be able to grant themselves a badge.
