ZENTRO TARGETED REPAIR — MESSAGE DELETE VISIBILITY, ACTIVITY POPUP/SOUND, EMAIL, FOLLOW COUNTS

This is based on the latest saved Zentro email-notification repair file. It preserves the existing photo/video publishing implementation; the new frontend patch only adds message-action styling and in-app notification popup/sound handling.

1) BACK UP your currently published root index.html first.
2) Replace ONLY the repository root index.html with this package's index.html. Do not delete or replace other app files.
3) The follower/following count logic is already included in this saved HTML. This package retains it.
4) The SQL file is the additive notification/follow-count migration. Since you already ran SQL and got Success, do not run it again unless we confirm it is needed or you receive a specific error.
5) To deliver EMAIL, deploy supabase/functions/zentro-notification-email/index.ts as Supabase Edge Function `zentro-notification-email`; configure secrets RESEND_API_KEY, RESEND_FROM_EMAIL (verified sender), ZENTRO_APP_URL=https://ofomukoroclinton-pixel.github.io/Zentro-/, and ZENTRO_WEBHOOK_SECRET. Then create a Supabase Database Webhook for INSERT on public.zentro_notifications, POSTing to that Edge Function with header x-zentro-webhook-secret equal to the secret. SQL alone cannot send email.
6) In Zentro Settings, tap “Enable popup + sound alerts” once. Sound plays while the app is open and after a user gesture; device volume must be on. A browser cannot force loud sound or guarantee sound when the app is fully closed. System push notifications when closed require Web Push/VAPID setup and Android/browser permissions.
7) Test with a second account: follow the profile and check follower/following counts; open Messages and confirm Edit/Delete buttons are visibly larger; generate a new notification and check popup/sound; after email webhook setup, check the recipient email and spam folder.

If any SQL error appears, stop and share the exact error. Do not paste private service-role keys into HTML or GitHub.
