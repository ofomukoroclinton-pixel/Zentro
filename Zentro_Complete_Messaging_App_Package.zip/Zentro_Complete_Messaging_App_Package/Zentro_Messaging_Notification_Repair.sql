-- ZENTRO MESSAGE + NOTIFICATION DUPLICATE-KEY REPAIR
-- Safe additive repair: does not delete messages, notifications, profiles, or accounts.
-- Fixes the zentro_notification_unique collision that currently rolls back message sending.
-- Run once in the Supabase SQL Editor for the Zentro project.

CREATE OR REPLACE FUNCTION public.zentro_create_activity_notification(
  p_recipient uuid,
  p_actor uuid,
  p_type text,
  p_message text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_actor_name text := 'Someone';
  v_message text;
BEGIN
  IF p_recipient IS NULL OR p_actor IS NULL OR p_recipient = p_actor THEN
    RETURN;
  END IF;

  SELECT COALESCE(NULLIF(BTRIM(display_name), ''), NULLIF(BTRIM(username), ''), 'Someone')
    INTO v_actor_name
  FROM public.profiles
  WHERE id = p_actor;

  IF v_actor_name IS NULL OR BTRIM(v_actor_name) = '' THEN
    v_actor_name := 'Someone';
  END IF;

  v_message := CASE p_type
    WHEN 'message' THEN v_actor_name || ' sent you a message.'
    WHEN 'follow' THEN v_actor_name || ' started following you.'
    WHEN 'like' THEN v_actor_name || ' liked your post.'
    WHEN 'comment' THEN v_actor_name || ' commented on your post.'
    WHEN 'match' THEN 'You have a new match with ' || v_actor_name || '.'
    ELSE COALESCE(NULLIF(BTRIM(p_message), ''), v_actor_name || ' interacted with you on Zentro.')
  END;

  -- Update the existing notification for this unique key instead of throwing an error.
  -- This is crucial: an exception in this trigger previously caused direct_messages INSERT to fail.
  INSERT INTO public.zentro_notifications (recipient_id, actor_id, type, message)
  VALUES (p_recipient, p_actor, p_type, v_message)
  ON CONFLICT ON CONSTRAINT zentro_notification_unique
  DO UPDATE SET
    message = EXCLUDED.message,
    created_at = now(),
    read_at = NULL;
END;
$$;

-- Realtime must include updates too because a repeated activity may update the same
-- unique notification row instead of inserting a second row.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime')
     AND NOT EXISTS (
       SELECT 1 FROM pg_publication_tables
       WHERE pubname = 'supabase_realtime'
         AND schemaname = 'public'
         AND tablename = 'zentro_notifications'
     ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.zentro_notifications';
  END IF;
END $$;

-- OWN CONTENT CONTROLS: members may edit/delete only messages they sent,
-- and delete only posts they own. These policies do not expose other members' content.
ALTER TABLE public.direct_messages ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "zentro_sender_update_own_messages" ON public.direct_messages;
CREATE POLICY "zentro_sender_update_own_messages"
  ON public.direct_messages FOR UPDATE TO authenticated
  USING (sender_id = auth.uid())
  WITH CHECK (sender_id = auth.uid());
DROP POLICY IF EXISTS "zentro_sender_delete_own_messages" ON public.direct_messages;
CREATE POLICY "zentro_sender_delete_own_messages"
  ON public.direct_messages FOR DELETE TO authenticated
  USING (sender_id = auth.uid());

ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "zentro_members_delete_own_posts" ON public.posts;
CREATE POLICY "zentro_members_delete_own_posts"
  ON public.posts FOR DELETE TO authenticated
  USING (user_id = auth.uid());
