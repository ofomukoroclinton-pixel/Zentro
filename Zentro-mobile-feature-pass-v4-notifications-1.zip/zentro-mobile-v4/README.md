# Zentro Mobile

React Native + Expo migration foundation for the Zentro PWA.

## Current migration foundation
- Persistent Supabase authentication
- Native Expo navigation
- Native feed screen
- Optimistic post-like UI (no whole-feed reload)
- Separate Home / Video / Community / Messages / Profile surfaces
- Deep-link scheme: `zentro://`
- Environment variables for Supabase

## Important
This is the first migration layer, not a claim that the complete Zentro app is finished.

The existing PWA is being used as the functional reference. The screenshot set is the visual reference. Existing Supabase tables and storage must be mapped before destructive schema changes are made.

## Run
1. Install Node.js.
2. `npm install`
3. Copy `.env.example` to `.env` and set the public Supabase URL/key.
4. `npm start`

Do not put Supabase service-role keys in the mobile app.
