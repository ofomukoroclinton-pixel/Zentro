import React, { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, FlatList, RefreshControl, StyleSheet, Text, View } from "react-native";
import PostCard from "../../src/components/PostCard";
import { getFeed, getLikedPostIds, type Post } from "../../src/lib/zentro";
import { useSession } from "../../src/store/session";

export default function Home() {
  const { user } = useSession();
  const [posts, setPosts] = useState<Post[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const load = useCallback(async () => {
    if (!user) return;
    const rows = await getFeed();
    const liked = await getLikedPostIds(user.id, rows.map(x => x.id));
    setPosts(rows.map(p => ({ ...p, liked: liked.has(p.id) })));
  }, [user]);
  useEffect(() => { load().catch(console.error); }, [load]);

  async function refresh() { setRefreshing(true); try { await load(); } finally { setRefreshing(false); } }

  if (!user) return <View style={styles.center}><Text>Sign in to use Zentro.</Text></View>;
  if (!posts.length) return <View style={styles.center}><Text style={styles.title}>Your Zentro feed</Text><Text>No posts yet.</Text></View>;

  return <FlatList
    data={posts}
    keyExtractor={p => p.id}
    contentContainerStyle={styles.list}
    refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}
    renderItem={({ item }) => <PostCard post={item} userId={user.id} />}
  />;
}
const styles=StyleSheet.create({list:{padding:12,paddingBottom:30},center:{flex:1,alignItems:"center",justifyContent:"center"},title:{fontSize:22,fontWeight:"800",marginBottom:8}});
