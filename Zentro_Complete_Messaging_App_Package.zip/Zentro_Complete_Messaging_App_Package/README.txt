ZENTRO — MESSAGING, POST DELETE, APP DISPLAY PACKAGE

WHAT IS INCLUDED
1. index.html — combined Zentro code including edit/delete controls for the signed-in member's own sent messages and delete controls for the signed-in member's own feed posts; also includes the current notification and Messenger code.
2. Zentro_Messaging_Notification_Repair.sql — repairs the zentro_notification_unique conflict and adds owner-only UPDATE/DELETE permissions for direct messages and owner-only DELETE permission for posts. It does not bulk-delete existing data.
3. manifest.json — configures Zentro to launch in standalone app display instead of showing browser address-bar UI when installed as a PWA.
4. sw.js — included copy of the current service worker; keep the current repository sw.js unchanged unless you specifically need to restore this copy.

EXACT DEPLOYMENT STEPS
A. Before editing, download/keep a backup of the currently published index.html.
B. In the GitHub repository, open the same root folder that currently contains index.html, sw.js, manifest.json, icon-192.png and icon-512.png.
C. Replace ONLY the root index.html with this package's index.html. Do not paste this entire file into the middle of the old code. Upload it as a complete file named exactly index.html.
D. In that same root folder, update manifest.json with the manifest.json from this package so its display mode is standalone. Keep icon-192.png and icon-512.png in that folder. Keep sw.js in place and do not delete it.
E. In the existing Supabase project, open SQL Editor, create a new query, paste the COMPLETE contents of Zentro_Messaging_Notification_Repair.sql, and run it ONCE. This SQL is required; HTML cannot change database permissions or repair the notification trigger by itself. Do not run it against a different Supabase project.
F. Open the installed Zentro app again after the GitHub Pages deployment completes. Test sending a message, then edit/delete your own sent message, and delete one of your own posts. Do not test by deleting other people's content.
G. For phone notifications, the operating system/browser must ask permission once. The app cannot grant OS notification permission silently. Tap Enable notifications in Zentro and approve the Android prompt. Notifications while the app is open use Supabase Realtime. Notifications while fully closed need a deployed push sender and VAPID/subscription setup; these files alone do not deploy that server component.

APP / CHROME NOTE
The standalone manifest removes the browser address bar and makes an installed PWA open in an app-like window. A web app still uses Android's installed browser engine internally, and live accounts, messages and feeds still require an internet connection to Supabase. This package does not turn the website into a native APK or make social features work fully offline. A native Android APK would be a separate build step.

SAFETY / VALIDATION
- The HTML file's non-empty inline JavaScript blocks passed Node syntax checks.
- Live database behavior has not been tested from this environment; verify after applying the SQL and publishing.
- No existing rows are bulk-deleted by this repair. Post/message delete buttons are limited in the frontend to the signed-in member's own content, and SQL adds owner checks at the database layer.
