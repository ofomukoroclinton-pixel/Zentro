const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-zentro-webhook-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const esc = (s: unknown) => String(s ?? "").replace(/[&<>"']/g, (c: string) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c] ?? c));

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers: corsHeaders });

  const expected = Deno.env.get("ZENTRO_WEBHOOK_SECRET") || "";
  if (!expected || req.headers.get("x-zentro-webhook-secret") !== expected) {
    return Response.json({ error: "Unauthorized" }, { status: 401, headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  const resendKey = Deno.env.get("RESEND_API_KEY") || "";
  const fromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "";
  const appUrl = Deno.env.get("ZENTRO_APP_URL") || "https://ofomukoroclinton-pixel.github.io/Zentro-/";
  if (!supabaseUrl || !serviceKey || !resendKey || !fromEmail) {
    return Response.json({ error: "Missing SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, RESEND_API_KEY or RESEND_FROM_EMAIL secret" }, { status: 500, headers: corsHeaders });
  }

  let payload: any;
  try { payload = await req.json(); } catch { return Response.json({ error: "Invalid JSON" }, { status: 400, headers: corsHeaders }); }
  const n = payload?.record || payload?.new || payload;
  const recipientId = n?.recipient_id;
  if (!recipientId || !n?.id) return Response.json({ error: "Webhook payload must include record.id and record.recipient_id" }, { status: 400, headers: corsHeaders });

  const adminHeaders = { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, "Content-Type": "application/json" };
  try {
    const userResp = await fetch(`${supabaseUrl}/auth/v1/admin/users/${encodeURIComponent(recipientId)}`, { headers: adminHeaders });
    if (!userResp.ok) throw new Error(`Could not resolve recipient email (${userResp.status})`);
    const user = await userResp.json();
    const email = user?.email;
    if (!email) return Response.json({ ok: true, skipped: "recipient has no registered email" }, { headers: corsHeaders });

    const type = String(n.type || "activity");
    const subjects: Record<string, string> = {
      message: "You have a new Zentro message",
      community_message: "New message in your Zentro community",
      match: "You have a new Zentro match",
      like: "Someone liked your Zentro post",
      comment: "Someone commented on your Zentro post",
      follow: "You have a new Zentro follower",
      post: "New post from someone you follow on Zentro",
    };
    const title = subjects[type] || "New activity on Zentro";
    const message = String(n.message || "You have new activity on Zentro.");
    const safeAppUrl = appUrl;
    const emailHtml = `<!doctype html><html><body style="margin:0;background:#f3f5fb;font-family:Arial,sans-serif;color:#172033"><div style="max-width:560px;margin:28px auto;padding:28px;background:#fff;border-radius:18px"><div style="font-size:28px;font-weight:800;color:#2563eb">Zentro</div><h2 style="margin:20px 0 12px">${esc(title)}</h2><p style="font-size:16px;line-height:1.6">${esc(message)}</p><p style="margin:28px 0"><a href="${esc(safeAppUrl)}" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;font-weight:700;padding:13px 20px;border-radius:10px">Open Zentro</a></p><p style="font-size:12px;color:#667085">Tap “Open Zentro” to go directly to the app. If the button does not work, copy this address into your browser: <br><a href="${esc(safeAppUrl)}">${esc(safeAppUrl)}</a></p></div></body></html>`;
    const emailResp = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from: fromEmail, to: [email], subject: title, text: `${message}\n\nOpen Zentro: ${safeAppUrl}`, html: emailHtml }),
    });
    const emailBody = await emailResp.text();
    if (!emailResp.ok) {
      console.error("Resend delivery failed", emailResp.status, emailBody);
      return Response.json({ error: `Email provider rejected the request (${emailResp.status})` }, { status: 502, headers: corsHeaders });
    }
    return Response.json({ ok: true, email: "sent", notification_id: n.id }, { headers: corsHeaders });
  } catch (err) {
    console.error("Zentro email notification dispatch failed", err);
    return Response.json({ error: String(err) }, { status: 500, headers: corsHeaders });
  }
});
