# Zentro mobile — feature pass v3

This pass adds the next layer of the migration:

- Separate Home, Community, Romance, and Video feed configurations.
- Reusable feed implementation while keeping each feed independently configurable.
- Notifications with Supabase realtime inserts so new notifications are appended rather than reloading the whole feed.
- Profile actions for verification, notifications, and create-post.
- Expo Router deep-link/app-link configuration for `zentro://` and `https://zentro.app/...`.
- Founder announcement surface marked official.
- Call architecture and dedicated call route. Actual WebRTC/TURN/signaling is intentionally not claimed as complete yet.
- Existing messaging, create-post, verification, and founder verification from v2 remain included.

Before production:
- Confirm exact screenshot dimensions/spacing/iconography against every supplied reference.
- Add the remaining screenshot-specific UI states and navigation transitions.
- Implement secure Edge Functions/RLS for verification and founder privileges.
- Implement WebRTC with TURN + authenticated signaling.
- Add government-ID upload/liveness and manual review evidence.
- Add automated tests for auth, RLS, posting, messaging, notifications, and verification.
