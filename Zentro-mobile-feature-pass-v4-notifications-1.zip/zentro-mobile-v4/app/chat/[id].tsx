import React, { useEffect, useState } from "react";
import { FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { getChat, sendMessage } from "../../src/lib/zentro";
import { useSession } from "../../src/store/session";

export default function Chat() {
  const { id, name }=useLocalSearchParams<{id:string;name?:string}>();
  const { user }=useSession();
  const [messages,setMessages]=useState<any[]>([]);
  const [text,setText]=useState("");
  const load=async()=>{if(user&&id)setMessages(await getChat(user.id,id))};
  useEffect(()=>{load().catch(console.error)},[user,id]);
  async function send(){const v=text.trim();if(!v||!user||!id)return;setText("");const optimistic={id:"local-"+Date.now(),sender_id:user.id,receiver_id:id,content:v,created_at:new Date().toISOString()};setMessages(x=>[...x,optimistic]);try{await sendMessage(user.id,id,v)}catch(e){setMessages(x=>x.filter(m=>m.id!==optimistic.id))}}
  return <KeyboardAvoidingView style={styles.page} behavior={Platform.OS==="ios"?"padding":undefined}>
    <View style={styles.top}><Pressable onPress={()=>router.back()}><Text>‹ Back</Text></Pressable><Text style={styles.title}>{name||"Chat"}</Text></View>
    <FlatList data={messages} keyExtractor={m=>m.id} contentContainerStyle={{padding:14}} renderItem={({item})=><View style={[styles.bubble,item.sender_id===user?.id?styles.mine:styles.theirs]}><Text>{item.content}</Text></View>}/>
    <View style={styles.composer}><TextInput value={text} onChangeText={setText} placeholder="Message..." style={styles.input}/><Pressable onPress={send} style={styles.send}><Text style={{color:"#fff",fontWeight:"800"}}>Send</Text></Pressable></View>
  </KeyboardAvoidingView>
}
const styles=StyleSheet.create({page:{flex:1},top:{height:58,flexDirection:"row",alignItems:"center",gap:20,paddingHorizontal:14,borderBottomWidth:1,borderBottomColor:"#eee"},title:{fontWeight:"900",fontSize:18},bubble:{maxWidth:"78%",padding:11,borderRadius:16,marginBottom:8},mine:{alignSelf:"flex-end",backgroundColor:"#dfe6ff"},theirs:{alignSelf:"flex-start",backgroundColor:"#eee"},composer:{flexDirection:"row",gap:8,padding:10,borderTopWidth:1,borderTopColor:"#eee"},input:{flex:1,borderWidth:1,borderColor:"#ddd",borderRadius:20,paddingHorizontal:15},send:{backgroundColor:"#111827",paddingHorizontal:16,justifyContent:"center",borderRadius:20}});
